using Terraria.ModLoader;

namespace OogAbOoGA
{
	class OogAbOoGA : Mod
	{
		public OogAbOoGA()
		{
		}
	}
}
